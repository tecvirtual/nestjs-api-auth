/* eslint-disable prettier/prettier */
export const jwtConstants = {
  secret: 'no utilizar en producción',
};
