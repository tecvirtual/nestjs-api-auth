/* eslint-disable prettier/prettier */
export enum Role {
    ADMIN = "admin",
    USER = "user",
  }